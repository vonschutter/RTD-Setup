
McMojave sddm theme for KDE Plasma desktop.

## Installation

sudo ./install.sh


