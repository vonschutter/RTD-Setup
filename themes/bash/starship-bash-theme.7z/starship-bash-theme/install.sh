#!/bin/bash
PUBLICATION="RTD Simple Global Theme Install"
VERSION="1.00"
#
#::             Linux bash Theme Installer Script
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::// Linux //::::
#::
#::     Author:   	Vonschutter adapted from Chris Titus "Mybash"
#::     Version 	1.00
#::
#::	Purpose: The purpose of the script is to install bash Theme globally
#::
#::
#::
#::
#::
#::
#::
#::
#::
#::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


home_directory=/home/${SUDO_USER}
home_template_directory=/etc/skel
base_target_directory=/usr/bin
base_config_directory=/etc/rtd
DEPENDENCIES='autojump bash bash-completion tar neovim curl trash-cli'


RC='\e[0m'
RED='\e[31m'
YELLOW='\e[33m'
GREEN='\e[32m'



command_exists () {
	command -v $1 >/dev/null 2>&1;
}

checkEnv() {
	## Check for requirements.
	REQUIREMENTS='groups sudo'
	if ! command_exists ${REQUIREMENTS}; then
		echo -e "${RED}To run me, you need: ${REQUIREMENTS}${RC}"
		exit 1
	fi

	## Check Package Handeler
	PACKAGEMANAGER='apt dnf zypper'
	for pgm in ${PACKAGEMANAGER}; do
		if command_exists ${pgm}; then
			PACKAGER=${pgm}
			echo -e "Using ${pgm}"
		fi
	done

	if [ -z "${PACKAGER}" ]; then
		echo -e "${RED}Can't find a supported package manager"
		exit 1
	fi
}

installDepend() {
	echo -e "${YELLOW}Installing dependencies...${RC}"
	for i in ${DEPENDENCIES} ; do
		sudo ${PACKAGER} install $i -y
	done
}


install_payload ()
{
	if [[ -e ./$(basename $0 )  ]]; then
		echo "OK I see the payload!"
	else
		echo "Problem: I am not in the right place: $(pwd) $(ls -l)"
		exit
	fi

	mkdir -p ${base_target_directory}
	mkdir -p ${base_config_directory}

	mv -f starship ${base_target_directory}/
	chmod 755 ${base_target_directory}/starship

	if mv -f starship.toml bashrc ${base_config_directory}/ ; then
		if mv ${home_directory}/.bashrc ${home_directory}/.config/.bashrc.bak ; then
			ln -svf ${base_config_directory}/bashrc ${home_directory}/.bashrc
		fi

		if rm ${home_template_directory}/.bashrc ; then
			ln -svf ${base_config_directory}/bashrc ${home_template_directory}/.bashrc
		fi
		chmod 755 ${base_config_directory}/bashrc
		chmod 755 ${base_config_directory}/starship.toml
		ln -svf ${base_config_directory}/starship.toml ${home_directory}/.config/starship.toml
		ln -svf ${base_config_directory}/starship.toml ${home_template_directory}/.config/starship.toml
	else
		echo "Error installing bashrc and toml files"
	fi
}



checkEnv
installDepend
install_payload && echo -e "${YELLOW} Make sure to use one of the NERD fonts in the included font themes...${RC}"



