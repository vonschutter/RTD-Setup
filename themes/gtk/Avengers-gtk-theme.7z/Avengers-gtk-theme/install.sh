#!/bin/bash
PUBLICATION="RTD Simple User Theme Install"
VERSION="1.00"
#
#::             Linux Theme Installer Script for GNOME
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::// Linux //::::
#::
#::     Author:   	Vonschutter
#::     Version 	1.00
#::
#::	Purpose: The purpose of the script is to install a KDE global theme
#::              and optonially enable it.
#::
#::
#::
#::
#::
#::
#::
#::
#::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::



#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#::::::::::::::                                          ::::::::::::::::::::::
#::::::::::::::          Script Settings                 ::::::::::::::::::::::
#::::::::::::::                                          ::::::::::::::::::::::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
SRC_DIR=$(cd $(dirname $0) && pwd)

#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#::::::::::::::                                          ::::::::::::::::::::::
#::::::::::::::          Script Settings                 ::::::::::::::::::::::
#::::::::::::::                                          ::::::::::::::::::::::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
function deploy_theme ()
{
  Avengers="Default"
  cd src/gtk-3.0/theme-assets
  ln -s -b ${Avengers}/nautilus_bg_img_bottom.jpg nautilus_bg_img_bottom.jpg
  ln -s -b ${Avengers}/nautilus_bg_img_top.jpg nautilus_bg_img_top.jpg

  cd ${SRC_DIR}
  ./Install

}


function apply_theme ()
{
if [ ! "$UID" -eq 0 ]; then
	gsettings set org.gnome.desktop.wm.preferences button-layout appmenu:minimize,maximize,close
	gsettings set org.gnome.desktop.interface gtk-theme Avengers
else
    sudo -H -u $SUDO_USER XDG_RUNTIME_DIR="/run/user/${SUDO_UID}" bash -c 'gsettings set org.gnome.desktop.wm.preferences button-layout appmenu:minimize,maximize,close ;\
    gsettings set org.gnome.desktop.interface gtk-theme Avengers'
fi
}

#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#::::::::::::::                                          ::::::::::::::::::::::
#::::::::::::::          Sript Flow Control              ::::::::::::::::::::::
#::::::::::::::                                          ::::::::::::::::::::::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

sudo -E  bash -c "$( declare -f deploy_theme ) ; deploy_theme"

case "$1" in
    --activate | --enable | --apply )
        apply_theme
        ;;
        *)
        echo "application of theme not requested"
        ;;
esac
