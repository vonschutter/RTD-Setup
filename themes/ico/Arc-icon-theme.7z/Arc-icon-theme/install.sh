#!/bin/bash
PUBLICATION="RTD Simple Global Theme Install"
VERSION="1.00"
#
#::             Linux icon Theme Installer Script
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::// Linux //::::
#::
#::     Author:   	Vonschutter
#::     Version 	1.00
#::
#::	Purpose: The purpose of the script is to install (an) icon theme(s) globally
#::              
#::
#::
#::
#::
#::
#::
#::
#::
#::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
#::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::



base_target_directory=/usr/share/icons
 if [[ -e ./$(basename $0 )  ]]; then 
 	_payload="$(ls -d */)" 
 else
 	echo "Problem: I am not in the right place: $(pwd) $(ls -l)"
 fi


mkdir -p  ${base_target_directory}
mv -f ${_payload} ${base_target_directory}/
chmod 755 -R ${base_target_directory}/*

